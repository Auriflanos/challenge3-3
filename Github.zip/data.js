module.exports = [
  {
    id: "mapas-com-react-usando-leaflet",
    url: "https://blog.rocketseat.com.br/content/images/2020/11/blog-thumb-utilizando-mapas-no-react-com-leaflet-1.jpg",
    title: "Mapas com React usando Leaflet! Um app incrível! Vem ver!",
    duration: "37 min",
    subtitle: "React com Leaflet"
  },
  {
    id: "construindo-um-app-com-mapas-usando-react-native-maps-e-mapbox",
    url: "https://blog.rocketseat.com.br/content/images/2020/10/teste.jpg",
    title: "Construindo App com Mapa usando React Native Maps e MapBox",
    duration: "57 min",
    subtitle: "React Native"
  },
  {
    id: "dark-mode-com-css-mudando-a-aparencia-do-blog-de-maneira-simples-e-rapida",
    url: "https://blog.rocketseat.com.br/content/images/2020/10/dark-mode-com-css-mudando-a-aparencia-do-blog-de-maneira-simples-e-rapida.jpg",
    title: "Dark Mode com CSS — mudando a aparência do Blog de maneira simples e rápida",
    duration: "57 min",
    subtitle: "CSS e HTML"
  }
]
